namespace MauiApp1.Theme
{
    public static class ThemeManager
    {
        public static void ChangeTheme(string theme)
        {
            // Logic for switching themes dynamically
        }
    }
}
