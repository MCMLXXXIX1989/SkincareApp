﻿namespace MauiApp1.Theme
{
    public class Theme
    {
        public string TaylorSwift { get; set; }
        public Color BackgroundColor { get; set; }
        public Color TextColor { get; set; }
        public Color ButtonColor { get; set; }
        public string FontFamily { get; set; }
    }
}
