namespace MauiApp1;

public partial class Dictionary1 : ResourceDictionary
{
	public Dictionary1()
	{
		InitializeComponent();
	}
}